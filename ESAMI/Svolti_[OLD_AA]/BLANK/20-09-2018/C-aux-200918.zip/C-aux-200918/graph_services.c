#include <stdlib.h>
#include <math.h>

#include "graph_services.h"
#include "graph.h"
#include "linked_list.h"


double dist(centrale* c1, centrale* c2){
	double dx = c1->x - c2->x;
	double dy = c1->y - c2->y;
	return sqrt((dx*dx) + (dy*dy));
}


void graph_print_powplant(graph* g) {
	if (g) {
		linked_list_iterator *it = linked_list_iterator_new(g->nodes);
		graph_node* cur = (graph_node*)linked_list_iterator_getvalue(it);
		while (linked_list_iterator_hasnext(it)) {
			printf("%s: ", ((centrale*)(cur->object))->name);
			linked_list_iterator *it2 = linked_list_iterator_new(cur->incident_edges);
			graph_edge* edge = linked_list_iterator_getvalue(it2);
			while (linked_list_iterator_hasnext(it2)) {
				printf("%s:%f ", edge->n2 == cur ? (((centrale*)(edge->n1->object))->name) : (((centrale*)(edge->n2->object))->name), edge->weight);
				edge = linked_list_iterator_next(it2);
			}
			printf("\n");
			linked_list_iterator_delete(it2);
			cur = linked_list_iterator_next(it);
		}
		linked_list_iterator_delete(it);
		printf("n_nodes:%d,  n_edges:%d\n", g->n_nodes, g->n_edges);
	}
	else {
		printf("ERROR - invocation with NULL in graph_print\n");
		return;
	}
}


graph* get_complete_graph(linked_list* pp){
	/*DA IMPLEMENTARE*/
	return NULL;
}


void set_weights_in_graph(graph* g){
	/*DA IMPLEMENTARE*/
}


linked_list* get_min_wire(graph* g){
	/*DA IMPLEMENTARE*/
	return NULL;
}