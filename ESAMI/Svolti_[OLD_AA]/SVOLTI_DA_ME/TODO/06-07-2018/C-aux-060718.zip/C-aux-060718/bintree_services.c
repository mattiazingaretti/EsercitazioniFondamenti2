#include "bintree.h"
#include "bintree_services.h"

int get_size_max_complete_subtree(binTree* bt){
    /*DA IMPLEMENTARE*/
    return 0;
}