#include <stdlib.h>

#include "graph_services.h"
#include "graph.h"
#include "linked_list.h"

int is_tree(graph* g){
	/*DA IMPLEMENTARE*/
	return 0;
}

int get_size_constrained_path(graph* g, graph_node* x, graph_node* y, graph_node* z){
	/*DA IMPLEMENTARE*/
	return 0;
}