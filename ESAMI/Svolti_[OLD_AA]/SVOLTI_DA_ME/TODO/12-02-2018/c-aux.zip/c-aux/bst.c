#include <stdlib.h>
#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include "bst.h"

static char *toUppercase(char *s) {
    /*OK*/
    char *u = malloc(sizeof(char)*(strlen(s)+1));
    strcpy(u, s);
    int i = 0;
    while(u[i] != 0) {
        u[i] = toupper(u[i]);
        i++;
    }
    return u;
}


static BinNode *BST_node_new(char *k) {
    /*OK*/
    BinNode *b = malloc(sizeof(BinNode));
	b->key = k;
	b->left = NULL;
	b->right = NULL;
	b->cont = 1;
	return b;
}

BST * BST_new() {
    /*OK*/
    BST *b = malloc(sizeof(BST));
    b->root = NULL;
	return b;
}


BinNode *BST_insert(BST *b, char *k) {
        /* DA IMPLEMENTARE */
        return NULL; // c
}

int BST_find(BST * b, char *k) {
        /*DA IMPLEMENTARE*/
        return -1; // per consentire compilazione
}

static void BST_print_aux(BinNode * t, int level, char pos) {
    /* OK, MODIFICABILE */
	if (t == NULL)
		return;

    int i;
    for (i = 0; i < level - 1; i++) {
    	printf("   ");
    }

    if (level > 0) {
    	printf(" %c:--", pos);
    }

    printf("key: |%s|\toccorrenze: %d\n", t->key, t->cont);

    BST_print_aux(t->left, level + 1, 'l');
    BST_print_aux(t->right, level + 1, 'r');
}

void BST_print(BST * b){
    /* OK, MODIFICABILE */
    if(b != NULL) return BST_print_aux(b->root, 0, ' ');
}

char *mostFrequentString(BST *t){
        /*DA IMPLEMENTARE*/
        return ""; // per consentire compilazione
}


int isBalanced(BST *t) {
        /*DA IMPLEMENTARE*/
        return -1; // per consentire compilazione
}



