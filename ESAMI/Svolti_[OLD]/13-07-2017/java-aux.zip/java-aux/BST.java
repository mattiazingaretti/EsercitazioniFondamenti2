public class BST{

    private BinNode root;

    public BST() {
        /* NON MODIFICARE */
        this.root = null;
    }

    public BinNode BST_insert(int x, int y) {
        /*DA IMPLEMENTARE*/
        return null; //istruzione aggiunta per permettere la compilazione
    }

     public void print(BinNode t, int level) {
        /* MODOFICABILE*/
        for (int i = 0; i < level - 1; i++) {
            System.out.print("   ");
        }

        if (level > 0) {
            System.out.print(" |--");
        }
        if (t == null){
            System.out.println("#");
            return;
        }


        System.out.println( "(" + t.getCoordinates()[0] + "," + t.getCoordinates()[1] + ")" );

        print(t.getLeft(), level + 1);
        print(t.getRight(), level + 1);
    }
    public void BST_print(){
        /* MODOFICABILE*/
        print(root, 0);
    }

    public int aligned(int x){
        /*DA IMPLEMENTARE*/
        return 0; //istruzione aggiunta per permettere la compilazione
    }

    public int rangeQ(int x1, int y1, int x2, int y2){
        /*DA IMPLEMENTARE*/
        return 0; //istruzione aggiunta per permettere la compilazione
    }

}
