    public class BinNode{
        /* NON MODIFICARE NIENTE IN QUESTO FILE */
        protected int[] coordinates;
        protected BinNode left;
        protected BinNode right;

        public BinNode(int x, int y) {
            coordinates = new int[2];
            coordinates[0] = x;
            coordinates[1] = y;
            this.left = null;
            this.right = null;
        }
        
        public BinNode getLeft(){
        	return left;
        }

        public BinNode getRight(){
        	return right;
        }
        
        public BinNode setLeft(BinNode n){
        	left = n;
        	return left;
        }

        public BinNode setRight(BinNode n){
        	right = n;
        	return right;
        }
        
        public int[] getCoordinates(){
            return coordinates;
        }
    }
