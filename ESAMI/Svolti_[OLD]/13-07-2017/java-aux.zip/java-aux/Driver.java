public class Driver {


    public static void main(String[] argv) {

    	BST b = new BST();
    	
        b.BST_insert(1,4);
        b.BST_insert(6,6);
        b.BST_insert(3,4);
        b.BST_insert(5,1);
        b.BST_insert(6,4);
        b.BST_insert(2,7);
        b.BST_insert(2,2);
        b.BST_insert(8,1);
        b.BST_insert(6,2);
        b.BST_insert(8,7);
        b.BST_insert(1,1);
        b.BST_insert(8,1);

        System.out.println("Albero: \n");
        b.BST_print();

        System.out.println("\nRicerca valore x: \n");
        for (int k=0; k<10; k++){
            System.out.println("Numero nodi con coordinata x="+k+": " + b.aligned(k)); 
        }

        System.out.println("\nRicerca range: \n");
        int [][] coordinatesTest = {
            {0, 0, 10, 10},
            {2, 2, 2, 2},
            {2, 6, 2, 6},
            {3, 0, 2, 10},
            {0, 3, 10, 2},
            {0, 4, 10, 4},
            {2, 4, 10, 4},
            {3, 5, 2, 1},
            {2, 2, 3, 4},
            {2, 7, 3, 4},
            {4, 3, 7, 5}
        };

        for (int i=0; i<coordinatesTest.length; i++){
            System.out.println("x1="+ coordinatesTest[i][0] +", x2="+coordinatesTest[i][1]+", y1="+coordinatesTest[i][2]+", y2="+coordinatesTest[i][3]+": " + b.rangeQ(coordinatesTest[i][0], coordinatesTest[i][1], coordinatesTest[i][2], coordinatesTest[i][3])); 
        }
        



    }
}
