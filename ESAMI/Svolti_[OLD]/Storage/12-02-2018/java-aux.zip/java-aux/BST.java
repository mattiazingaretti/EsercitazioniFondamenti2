public class BST{

    private BinNode root;

    public BST() {
        this.root = null;
    }

    public BinNode insert(String k) {
        /* DA IMPLEMENTARE */
        return null; // per consentire compilazione
    }

    public int find(String k) {
        /* DA IMPLEMENTARE */
        return -1; // per consentire compilazione
    }

    private void print(BinNode t, int level, char pos) {
        /* MODIFICABILE */
        if (t==null) return;
        for (int i = 0; i < level - 1; i++) {
            System.out.print("   ");
        }

        if (level > 0) {
            System.out.print(" "+pos+":--");
        }

        System.out.println("key: " + t.getKey() + "     occorrenze: " + t.getCont());

        print(t.getLeft(), level + 1,'l');
        print(t.getRight(), level + 1,'r');
    }

    public void BST_print(){
        if (root!=null)
            print(this.root, 0,' ');
    }

    public String mostFrequentString(){
        /* DA IMPLEMENTARE */
        return ""; // per consentire compilazione
    }

    public int isBalanced() {
        /* DA IMPLEMENTARE */
        return -1; // per consentire compilazione
    }


}
