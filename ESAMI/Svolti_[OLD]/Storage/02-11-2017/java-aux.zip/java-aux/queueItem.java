//classe ausiliaria per l'utilizzo della coda
//si noti NON E' public!!!

class queueItem<T> {
    T item;
    queueItem<T> next;
}
