#ifndef MAX_LEVEL_H
#define	MAX_LEVEL_H

#ifdef	__cplusplus
extern "C" {
#endif

#include "tree.h"
    
int max_level(node_tree * node_tree);

#ifdef	__cplusplus
}
#endif

#endif	/* MAX_LEVEL_H */