#ifndef PARSE_TREE_H
#define	PARSE_TREE_H

#ifdef	__cplusplus
extern "C" {
#endif

#include "tree.h"
    
node_tree * parse_tree();

#ifdef	__cplusplus
}
#endif

#endif	/* PARSE_TREE_H */