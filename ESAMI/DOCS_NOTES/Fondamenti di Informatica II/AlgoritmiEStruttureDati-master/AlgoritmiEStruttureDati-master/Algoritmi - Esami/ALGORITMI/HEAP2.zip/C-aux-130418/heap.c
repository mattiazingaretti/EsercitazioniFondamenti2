#include <stdlib.h>
#include <stdio.h>
#include "heap.h"
#include "_heap.h"

heap * heap_new(HEAP_TYPE is_min_heap, int capacity) {
	return NULL;
}

HEAP_TYPE heap_type(heap * hh) {
	return 0;
}

int heap_peek(heap * hh) {
	return 0;
}

heap_entry * heap_add(heap * hh, int key) {
	return NULL;
}

int get_key_entry(heap_entry * ee) {
	return 0;
}

int heap_size(heap * hh) {
	return 0;
}

int heap_poll(heap * hh) {
	return 0;
}

void heap_delete(heap * hh) {
	return;
}

heap * array2heap(int * array, int size, HEAP_TYPE is_min_heap) {
	return NULL;
}

void heap_print(heap * hh) {
	return;
}

void heap_sort(int * array, int size) {
	return;
}

void heap_update_key(heap * hh, heap_entry * ee, int key) {
	return;        
}

