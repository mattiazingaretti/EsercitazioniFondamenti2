#include <stdlib.h>
#include <stdio.h>

#include "iter_postorder.h"
#include "stack.h"

void iterative_postorder_visit(node_tree * node) {

}