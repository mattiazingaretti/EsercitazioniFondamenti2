#include <stdlib.h>
#include <stdio.h>

#include "queue.h"
#include "max_level.h"

int max_level(node_tree * n) {
	return 0;
}