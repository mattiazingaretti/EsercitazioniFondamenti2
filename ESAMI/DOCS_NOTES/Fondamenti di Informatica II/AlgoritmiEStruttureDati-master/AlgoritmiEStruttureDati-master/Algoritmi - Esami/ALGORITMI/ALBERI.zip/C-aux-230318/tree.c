#include <stdlib.h>
#include <stdio.h>

#include "tree.h"

node_tree * new_node_tree(int info) {
	return NULL;	
}

int get_node_info(node_tree * n) {
	return 0;
}

void set_first_child(node_tree * n, node_tree * first_child) {
	return;
}

node_tree * get_first_child(node_tree * n) {
	return NULL;
}

void set_next_sibling(node_tree * n, node_tree * next_sibling) {
	return;
}

node_tree * get_next_sibling(node_tree * n) {
	return NULL;
}

void delete_tree(node_tree * nt) {
	return;
}

void print_tree(node_tree * node) {
	return;
}
