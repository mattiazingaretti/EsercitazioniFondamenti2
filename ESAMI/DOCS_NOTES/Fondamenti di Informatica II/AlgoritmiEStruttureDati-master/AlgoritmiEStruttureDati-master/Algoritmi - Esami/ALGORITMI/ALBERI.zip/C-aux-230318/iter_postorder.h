#ifndef ITER_POSTORDER_H
#define	ITER_POSTORDER_H

#ifdef	__cplusplus
extern "C" {
#endif

#include "tree.h"
    
void iterative_postorder_visit(node_tree * node);

#ifdef	__cplusplus
}
#endif

#endif	/* ITER_POSTORDER_H */