#ifndef _BSTC
#define _BSTC

#include "bst.h"
#include "bstnode.h"
#include <math.h>
#include <stdlib.h>
#include <assert.h>
#include <stdio.h>

#define PI 3.14159265


bst *newBST() {
    bst *tmp = malloc(sizeof(bst));
    tmp->root = NULL;
    tmp->size = 0;
    return tmp;
}

static double raggio(double x, double y) {
    return sqrt(x*x+y*y);
}

static double raggiop(bstnode *u) {
    return raggio(u->x_coord, u->y_coord);
}

static double fase(double x, double y) {
    if(x == 0)
        if(y == 0) return 0;
        else if(y > 0) return PI/2;
        else return -PI/2;
    double a = atan(y/x);
    if(x > 0) return a;
    else if(y >= 0) return a + PI;
    else return a - PI;
}

static double fasep(bstnode *p) {
    return fase(p->x_coord, p->y_coord);
}

static void _print(bstnode *t, int ind, char *msg) {
    for(int i = 0; i < ind; i++) printf("--");
    if(t == NULL) { printf("# (%s)\n", msg); return; }
    printf("[NODE (x=%g, y=%g) (raggio=%g, fase=%g)] (%s)\n", t->x_coord, t->y_coord, raggiop(t), fasep(t), msg);
    _print(t->left, ind+1, "figlio SX");
    _print(t->right, ind+1, "figlio DX");
    return;
}

void print(bst *t) {
    printf("Stampa albero in pre-ordine. N.ro nodi: %d\n", t->size);
    _print(t->root, 0, "root");
    printf("Fine stampa albero in pre-ordine\n");
}

bstnode *insert(bst *t, double x, double y) {
    /* DA IMPLEMENTARE */
    return NULL; /* SOLO PER COMPILAZIONE */
}


int corona(bst *t, double r1, double r2) {
    /* DA IMPLEMENTARE */
    return -1; /* SOLO PER COMPILAZIONE */
}

double maxCorona(bst *t) {
    /* DA IMPLEMENTARE */
    return -1; /* SOLO PER COMPILAZIONE */
}

#endif
