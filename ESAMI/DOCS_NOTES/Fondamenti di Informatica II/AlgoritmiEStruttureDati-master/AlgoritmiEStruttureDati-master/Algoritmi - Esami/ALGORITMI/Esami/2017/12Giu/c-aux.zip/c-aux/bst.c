#include <stdlib.h>
#include <stdio.h>
#include "bst.h"
#include "queue.h"

static BinNode * BST_node_new(int k) {
        BinNode * b = malloc(sizeof(BinNode));
	b->key = k;
	b->left = NULL;
	b->right = NULL;

	return b;
}

BST * BST_new() {
        BST * b = malloc(sizeof(BST));
        b->root = NULL;

	return b;
}


BinNode * BST_insert(BST * b, int k) {
    /*DA IMPLEMENTARE*/
    return NULL; //questa istruzione è stata inserita per permettere la compilazione e va rimossa
}


BinNode * BST_find(BST * b, int k) {
    /*DA IMPLEMENTARE*/
    return NULL; //questa istruzione è stata inserita per permettere la compilazione e va rimossa
}

static void BST_delete_aux(BinNode * t) {
	if (t == NULL)
		return;

        BST_delete_aux(t->left);
        BST_delete_aux(t->right);
	free(t);
}

void BST_delete(BST * b) {
	if (b == NULL)
		return;

        BST_delete_aux(b->root);
        free(b);
}

void BST_print_aux(BinNode * t, int level) {
	if (t == NULL)
		return;

    int i;
    for (i = 0; i < level - 1; i++) {
    	printf("   ");
    }

    if (level > 0) {
    	printf(" |--");
    }

    printf("%d\n", t->key);

    BST_print_aux(t->left, level + 1);
    BST_print_aux(t->right, level + 1);
}

void BST_print(BST * b){
    return BST_print_aux(b->root, 0);
}


int maxOnLevel (BST * b, int level){
    /*DA IMPLEMENTARE*/
    return 0; //questa istruzione è stata inserita per permettere la compilazione e va rimossa
}
