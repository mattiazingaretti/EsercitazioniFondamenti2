public class Tree{

    private Node root;
    private int size;


    public Tree(){
        this.root=new Node("",1024,true);
        this.size=1;
    }    
    
    public Node getRoot(){
        return root;
    }


    public int getSize(){
        return size;
    }

    public Node insertFile(Node parent, String nome, int size){
        /* DA IMPLEMENTARE */
        return null; //istruzione inserita per permettere la compilazione
    }
    public Node insertDir(Node parent, String nome){
        /* DA IMPLEMENTARE */
        return null; //istruzione inserita per permettere la compilazione
    }


    public void findAll(String s){
        /* DA IMPLEMENTARE */
    }


    public int cleanSmallDirs(int min){
        /* DA IMPLEMENTARE */
        return 0; //istruzione inserita per permettere la compilazione
    }


}