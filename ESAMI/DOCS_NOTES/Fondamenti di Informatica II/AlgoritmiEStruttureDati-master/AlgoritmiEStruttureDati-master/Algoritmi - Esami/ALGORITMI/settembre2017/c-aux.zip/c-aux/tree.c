#ifndef TREEC
#define TREEC

#include "tree.h"
#include "node.h"

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int nodeInTree(Tree *t, Node *v) {
    if(v == NULL) return 0;
    if(v == t->root) return 1;
    return nodeInTree(t, v->parent);
}

Tree *newTree() {
    Tree *new = malloc(sizeof(Tree));
    new->root = newNode("Volume", 1024, 1);
    new->size = 1;
    return new;
}

/* DA IMPLEMENTARE */
Node *insertFile(Tree *t, Node *p, char *nome, int size){
    return NULL; // inserita per permettere la compilazione
}

/* DA IMPLEMENTARE */
Node *insertDir(Tree *t, Node *p, char *nome){
    return NULL; // inserita per permettere la compilazione
}

/* DA IMPLEMENTARE */
int cleanSmallDirs(Tree *t, int min) {
    return 0; // inserita per permettere la compilazione
}

/* DA IMPLEMENTARE */
void findAll(Tree *t, char *s) {
    return; // inserita per permettere la compilazione
}


#endif
