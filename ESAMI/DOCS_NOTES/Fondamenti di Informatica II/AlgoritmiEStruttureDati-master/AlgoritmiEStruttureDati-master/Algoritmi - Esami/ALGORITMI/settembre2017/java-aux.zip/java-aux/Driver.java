import java.util.ArrayList;
import java.util.concurrent.ThreadLocalRandom;

public class Driver {

    public static void main(String[] argv) {

    	Tree t = new Tree();
        ArrayList<Node> directories;
        ArrayList<Node> files;        
        directories = new ArrayList<Node>();
        files = new ArrayList<Node>();

        
        directories.add(t.getRoot());

        int i;
        int indexParent;
        Node nuovoNodo;
        for (i=0; i<30; i++){
            indexParent = ThreadLocalRandom.current().nextInt(0, directories.size());
            if (Math.random()<0.3){
                nuovoNodo = t.insertDir(directories.get(indexParent), "dir"+i);
                directories.add(nuovoNodo);
            }else{
                int size = ThreadLocalRandom.current().nextInt(1, 1024+512);
                nuovoNodo = t.insertFile(directories.get(indexParent), "file"+i+".txt", size);
                files.add(nuovoNodo);
            }
        }
        indexParent = ThreadLocalRandom.current().nextInt(0, directories.size());
        nuovoNodo = t.insertDir(directories.get(indexParent), "sameName");
        for (i=0;i<5;i++){
            indexParent = ThreadLocalRandom.current().nextInt(0, directories.size());
            int size = ThreadLocalRandom.current().nextInt(1, 1024+512);
            nuovoNodo = t.insertFile(directories.get(indexParent), "sameName", size);
        }


    	
        System.out.println("\n File System: ");
        TreePrinter tp = new TreePrinter(t.getRoot());
        tp.printTree(); 

        System.out.println("\n findAll test: ");
        for (i=0; i<directories.size(); i++){
             System.out.println("Searching " + directories.get(i).getNome());
             t.findAll(directories.get(i).getNome());
         }
         for (i=0; i<files.size(); i++){
             System.out.println("Searching " + files.get(i).getNome());
             t.findAll(files.get(i).getNome());
         }
         System.out.println("Searching sameName");
         t.findAll("sameName");
        

        System.out.println("\n Pulizia cartelle: ");
        int rimosso = t.cleanSmallDirs(2000);
        System.out.println("\t Cancellati " + rimosso + " Bytes");

        System.out.println("\n Nuovo File System: ");
        tp.printTree(); 
    }
}
