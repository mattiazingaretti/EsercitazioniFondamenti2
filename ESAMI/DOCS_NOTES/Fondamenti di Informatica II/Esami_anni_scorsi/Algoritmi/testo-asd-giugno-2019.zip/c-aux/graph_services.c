#include "graph.h"

void connectedComponents(graph *g) {
        /* DA IMPLEMENTARE */
}
  
void distances(graph *g, graph_node *s) {
        /* DA IMPLEMENTARE */     
}
