public class GraphServices<V>{

  public static <V> void connectedComponents(Graph<V> g) {
		/* DA IMPLEMENTARE */
  }
  
  public static <V> void distances(Graph<V> g, GraphNode<V> s) {
		/* DA IMPLEMENTARE */	  
  }

}
