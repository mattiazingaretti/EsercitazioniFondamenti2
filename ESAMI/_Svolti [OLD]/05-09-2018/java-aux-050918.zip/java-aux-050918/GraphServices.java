import java.util.Iterator;
import java.util.LinkedList;

public class GraphServices {
	
	public static double dist(City c1, City c2){
		double dx = c1.x - c2.x;
		double dy = c1.y - c2.y;
		return Math.sqrt((dx*dx) + (dy*dy));
	}
	
	/*
	 * Data una lista contenente un elenco di citta', ritorna un puntatore al grafo completo avente:
	 * - un nodo per ogni citta'
	 * - un arco per ogni coppia di citta' (x,y) avente come peso la distanza euclidea tra x ed y
	 */
	public static Graph getCompleteGraph(LinkedList<City> l1) {
		/*DA IMPLEMENTARE*/
		return null;
	}

	/*
	 * Dato un grafo, ritorna un puntatore al minheap costituito dagli archi del grafo, usando il peso degli archi come priorita'.
	 */
	public static MinHeap<GraphEdge> getMinHeapEdges(Graph g) {
		/*DA IMPLEMENTARE*/
		return null;
	}

	/*
	 * Dato un grafo, ritorna una lista degli archi che rappresentano un Minimum Spanning Tree del grafo.
	 */
	public static LinkedList<GraphEdge> getMST(Graph g) {
		/*DA IMPLEMENTARE*/
		return null;
	}
}

class City {
	String name;
	double x;
	double y;
	
	public City(String name, double x, double y) {
		super();
		this.name = name;
		this.x = x;
		this.y = y;
	}

	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public double getX() {
		return x;
	}
	
	public void setX(double x) {
		this.x = x;
	}
	
	public double getY() {
		return y;
	}
	
	public void setY(double y) {
		this.y = y;
	}
	
	@Override
	public String toString() {
		return "City [name=" + name + ", x=" + x + ", y=" + y + "]";
	}
}
