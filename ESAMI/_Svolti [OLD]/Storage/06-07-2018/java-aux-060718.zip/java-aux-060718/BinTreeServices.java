public class BinTreeServices{

    /**
     * Dato in input un albero t, ritorna il numero di nodi del sottoalbero completo maggiore di t.
    */
    public static int getSizeMaxCompleteSubtree(BinTree bt){
        /*DA IMPLEMENTARE*/
        return 0;
    }
}