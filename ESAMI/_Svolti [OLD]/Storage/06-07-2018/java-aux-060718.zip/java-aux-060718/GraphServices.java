public class GraphServices {
	/**
	 * Dato un grafo in input, la funziona ritorna 1 se il grafo è un albero, 0 altrimenti.
	*/
	public static int isTree(Graph g){
		/*DA IMPLEMENTARE*/
		return 0;
	}

	/**
	 * Dato un grafo g e tre nodi x,y,z appartenenti a g, la funziona ritorna la lunghezza
	 * del cammino minimo che connette x e z in g, passando per y. Se non esiste alcun cammino
	 * la funzione deve ritornare il valore di default -1.
	*/
	public static int getSizeConstrainedPath(Graph g, GraphNode x, GraphNode y, GraphNode z){
		/*DA IMPLEMENTARE*/
		return 0;
	}
}